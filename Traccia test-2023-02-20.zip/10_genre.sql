INSERT INTO `genre` (`genre_id`, `genre_name`) VALUES
	(1, 'Action'),
	(8, 'Animated'),
	(2, 'Comedy'),
	(3, 'Drama'),
	(4, 'Horror'),
	(5, 'Musical'),
	(6, 'Thriller'),
	(7, 'Western');

