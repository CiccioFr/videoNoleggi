INSERT INTO `role` (`role_id`, `role_name`) VALUES
	(1, 'ACTOR'),
	(2, 'DIRECTOR');
