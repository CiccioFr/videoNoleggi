INSERT INTO `language` (`language_id`, `language_name`) VALUES
	(1, 'English'),
	(5, 'French'),
	(2, 'Italian'),
	(3, 'Japanese'),
	(4, 'Mandarin'),
	(9, 'Norwegian'),
	(6, 'Spanish');

